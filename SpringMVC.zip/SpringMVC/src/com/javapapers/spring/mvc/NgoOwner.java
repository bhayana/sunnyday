package com.javapapers.spring.mvc;

public class NgoOwner {

	public void test(){
		System.out.println("inside test of NGOOwner");
	}
}
