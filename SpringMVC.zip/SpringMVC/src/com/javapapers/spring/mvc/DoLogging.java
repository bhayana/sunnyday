package com.javapapers.spring.mvc;

public class DoLogging {
	
	public void singBeforeQuest(){
		System.out.println("Falala;Theknightissobrave!");
		}
		public void singAfterQuest(){
		System.out.println(
		"Tee heehe;Thebraveknightdidembarkonaquest!");
		}

}
