package com.javapapers.spring.mvc;

public interface Performer {
	
	void perform();

}
