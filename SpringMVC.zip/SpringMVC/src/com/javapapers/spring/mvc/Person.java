package com.javapapers.spring.mvc;

public interface Person {
	
public void getName();


}
