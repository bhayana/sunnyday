package ws;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;

import org.apache.tomcat.jni.User;

import com.javapapers.spring.mvc.UserDetails;


@Path(value="user")
public class Userestful {

	
	
/*
 * 	@Path("/findall")
 */
	@GET
	@Produces("application/json")
	public Response findAl()
	{
		String hello="hello world";
		return Response.ok().entity(new UserDetails("Rajan","rajan.bhayana@gmail.com"))
				.header("Access-Control-Allow-Origin","*")
				.header("Access-Control-Allow-Credentials", "true")
				.header("Access-Control-Allow-Headers", "Content-Type, Accept, X-Requested-With")
				.header("Access-Control-Allow-Methods", "GET,POST,DELETE,PUT,OPTIONS,HEAD")
				.build();
	//	return "Hello World";
	}
	
	@PUT
    //@Path("{id}")
	@Path("/update/{username}")
	@Consumes("application/json")
	@Produces("application/json")
	public Response update(@PathParam("username") String userName , @QueryParam("carcolor") String color)
	{
		String hello="hello world";
		return Response.ok().entity(new UserDetails("Rajan","rajan.bhayana@gmail.com"))
				.header("Access-Control-Allow-Origin","*")
				.header("Access-Control-Allow-Credentials", "true")
				.header("Access-Control-Allow-Headers", "Content-Type, Accept, X-Requested-With")
				.header("Access-Control-Allow-Methods", "GET,POST,DELETE,PUT,OPTIONS,HEAD")
				.build();
	//	return "Hello World";
	}
	 
	
	/* @Path("/add")
	  @POST
	  @Consumes("application/json")
	  @Produces("application/json")
	  public Response addActor(@QueryParam("name") String name) {
		 
	   System.out.println("getting user id: ");
	   return Response.ok().entity(new UserDetails("Rajan","rajan.bhayana@gmail.com"))
				.header("Access-Control-Allow-Origin","*")
				.header("Access-Control-Allow-Credentials", "true")
				.header("Access-Control-Allow-Headers", "Content-Type, Accept, X-Requested-With")
				.header("Access-Control-Allow-Methods", "GET,POST,DELETE,PUT,OPTIONS,HEAD")
				.build();
	  }*/
	 
	 
	@POST
	  @Consumes("text/plain")
	  @Produces("text/plain")
    public String create(String user) {
		UserDetails ud=new UserDetails();
		ud.setEmailId("bkbask");
		ud.setUserName("dcnbdsn");
        return "hello";
    }
	
	
	 
	public void getConnection()
	{
		
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root", "Sadhna@22");
			Statement st=null;
			st = connection.createStatement();
			String sql;
			sql="Select name from login";
			ResultSet rs= st.executeQuery(sql);
			 while(rs.next()){
		         //Retrieve by column name
		      
		         String name = rs.getString("name");

		         System.out.println(" Name: " + name);
		      }

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			//return ;
		}catch (ClassNotFoundException e) {
			System.out.println("Where is your MySQL JDBC Driver?");
			e.printStackTrace();
			//return;
		}
	
	
	
	
	}
}
